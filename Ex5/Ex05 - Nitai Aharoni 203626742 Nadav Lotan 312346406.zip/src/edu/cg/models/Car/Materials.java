package edu.cg.models.Car;

import com.jogamp.opengl.GL2;

public class Materials {
    // Use this class to update the color of the vertexes when drawing.
    private static final float DARK_GRAY[] = {0.2f, 0.2f, 0.2f};
    private static final float DARK_RED[] = {0.25f, 0.01f, 0.01f};
    private static final float RED[] = {0.7f, 0f, 0f};
    private static final float BLACK[] = {0.05f, 0.05f, 0.05f};

    public static void SetMetalMaterial(GL2 gl, float[] color) {
        gl.glColor3fv(color, 0);
    }

    public static void SetBlackMetalMaterial(GL2 gl) {
        SetMetalMaterial(gl, BLACK);
    }

    public static void SetRedMetalMaterial(GL2 gl) {
        SetMetalMaterial(gl, RED);
    }

    public static void SetDarkRedMetalMaterial(GL2 gl) {
        SetMetalMaterial(gl, DARK_RED);
    }

    public static void SetDarkGreyMetalMaterial(GL2 gl) {
        SetMetalMaterial(gl, DARK_GRAY);
    }

    public static void setMaterialTire(GL2 gl) {
        float col[] = {.05f, .05f, .05f};
        gl.glColor3fv(col, 0);
    }

    public static void setMaterialRims(GL2 gl) {
        gl.glColor3fv(DARK_GRAY, 0);
    }

}
