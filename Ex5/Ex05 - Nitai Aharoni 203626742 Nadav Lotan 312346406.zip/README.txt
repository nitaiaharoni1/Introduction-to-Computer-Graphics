implementation:
As we needed to view all what's being done in the application, 
we started off with SetupCamera.

Afterwards we moved on to the main algorithm (trackball) 
and the transformations, which was a bit complicated.


When those were done we have moved on to Back,
for viewing and learning purposes, 
and implemented Center, Front and Wheels.


After finishing we merged all compartments of the car together
and did some debugging and small fixes to make the car look this way,
hopefully the result will suffice.

