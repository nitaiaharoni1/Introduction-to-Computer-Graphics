// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg;

import edu.cg.menu.MenuWindow;

public class Main
{
    public static void main(final String[] args) {
        final MenuWindow mw = new MenuWindow();
        mw.setVisible(true);
    }
}
