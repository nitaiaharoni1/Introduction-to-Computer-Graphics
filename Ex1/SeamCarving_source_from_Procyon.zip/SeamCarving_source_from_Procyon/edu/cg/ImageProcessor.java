// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class ImageProcessor extends FunctioalForEachLoops
{
    public final Logger logger;
    public final BufferedImage workingImage;
    public final RGBWeights rgbWeights;
    public final int inWidth;
    public final int inHeight;
    public final int workingImageType;
    public final int outWidth;
    public final int outHeight;
    
    public ImageProcessor(final Logger logger, final BufferedImage workingImage, final RGBWeights rgbWeights, final int outWidth, final int outHeight) {
        this.logger = logger;
        this.workingImage = workingImage;
        this.rgbWeights = rgbWeights;
        this.inWidth = workingImage.getWidth();
        this.inHeight = workingImage.getHeight();
        this.workingImageType = workingImage.getType();
        this.outWidth = outWidth;
        this.outHeight = outHeight;
        this.setForEachInputParameters();
    }
    
    public ImageProcessor(final Logger logger, final BufferedImage workingImage, final RGBWeights rgbWeights) {
        this(logger, workingImage, rgbWeights, workingImage.getWidth(), workingImage.getHeight());
    }
    
    public BufferedImage changeHue() {
        this.logger.log("Prepareing for hue changing...");
        final int r = this.rgbWeights.redWeight;
        final int g = this.rgbWeights.greenWeight;
        final int b = this.rgbWeights.blueWeight;
        final int max = this.rgbWeights.maxWeight;
        final BufferedImage ans = this.newEmptyInputSizedImage();
        final Color c;
        final int n;
        final int n2;
        final int red;
        final int n3;
        final int green;
        final int n4;
        final int blue;
        final Color color;
        final BufferedImage bufferedImage;
        this.forEach((y, x) -> {
            c = new Color(this.workingImage.getRGB(x, y));
            red = n * c.getRed() / n2;
            green = n3 * c.getGreen() / n2;
            blue = n4 * c.getBlue() / n2;
            color = new Color(red, green, blue);
            bufferedImage.setRGB(x, y, color.getRGB());
            return;
        });
        this.logger.log("Changing hue done!");
        return ans;
    }
    
    public final void setForEachInputParameters() {
        this.setForEachParameters(this.inWidth, this.inHeight);
    }
    
    public final void setForEachOutputParameters() {
        this.setForEachParameters(this.outWidth, this.outHeight);
    }
    
    public final BufferedImage newEmptyInputSizedImage() {
        return this.newEmptyImage(this.inWidth, this.inHeight);
    }
    
    public final BufferedImage newEmptyOutputSizedImage() {
        return this.newEmptyImage(this.outWidth, this.outHeight);
    }
    
    public final BufferedImage newEmptyImage(final int width, final int height) {
        return new BufferedImage(width, height, this.workingImageType);
    }
    
    public BufferedImage greyscale() {
        this.logger.log("creates a greyscale image.");
        final int r = this.rgbWeights.redWeight;
        final int g = this.rgbWeights.greenWeight;
        final int b = this.rgbWeights.blueWeight;
        final int rgb = this.rgbWeights.weightsAmount;
        final BufferedImage ans = this.newEmptyInputSizedImage();
        final Color c;
        final int n;
        final int n2;
        final int n3;
        final int n4;
        final int mean;
        final Color grey;
        final BufferedImage bufferedImage;
        this.forEach((y, x) -> {
            c = new Color(this.workingImage.getRGB(x, y));
            mean = (n * c.getRed() + n2 * c.getGreen() + n3 * c.getBlue()) / n4;
            grey = new Color(mean, mean, mean);
            bufferedImage.setRGB(x, y, grey.getRGB());
            return;
        });
        return ans;
    }
    
    public BufferedImage nearestNeighbor() {
        this.logger.log("applies nearest neighbor interpolation.");
        final BufferedImage ans = this.newEmptyOutputSizedImage();
        this.pushForEachParameters();
        this.setForEachOutputParameters();
        final int imgX;
        final int imgY;
        final int imgX2;
        final int imgY2;
        final BufferedImage bufferedImage;
        this.forEach((y, x) -> {
            imgX = Math.round(x * this.inWidth / this.outWidth);
            imgY = Math.round(y * this.inHeight / this.outHeight);
            imgX2 = Math.min(imgX, this.inWidth - 1);
            imgY2 = Math.min(imgY, this.inHeight - 1);
            bufferedImage.setRGB(x, y, this.workingImage.getRGB(imgX2, imgY2));
            return;
        });
        this.popForEachParameters();
        return ans;
    }
    
    public final BufferedImage duplicateWorkingImage() {
        final BufferedImage output = this.newEmptyInputSizedImage();
        this.forEach((y, x) -> output.setRGB(x, y, this.workingImage.getRGB(x, y)));
        return output;
    }
}
