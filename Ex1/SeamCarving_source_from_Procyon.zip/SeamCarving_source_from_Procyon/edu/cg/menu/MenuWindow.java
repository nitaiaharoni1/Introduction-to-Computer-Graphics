// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg.menu;

import java.util.Arrays;
import java.awt.Color;
import edu.cg.SeamsCarver;
import edu.cg.RGBWeights;
import edu.cg.ImageProcessor;
import java.awt.GridLayout;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.JPanel;
import edu.cg.menu.components.LogField;
import edu.cg.menu.components.ActionsController;
import edu.cg.menu.components.ScaleSelector;
import edu.cg.menu.components.ColorMixer;
import edu.cg.menu.components.ImagePicker;
import java.awt.image.BufferedImage;
import edu.cg.Logger;
import javax.swing.JFrame;

public class MenuWindow extends JFrame implements Logger
{
    private BufferedImage workingImage;
    private boolean[][] imageMask;
    private String imageTitle;
    private ImagePicker imagePicker;
    private ColorMixer colorMixer;
    private ScaleSelector scaleSelector;
    private ActionsController actionsController;
    private LogField logField;
    private static /* synthetic */ int[] $SWITCH_TABLE$edu$cg$menu$components$ScaleSelector$ResizingOperation;
    
    public MenuWindow() {
        this.setTitle("Ex1: Image Processing Application");
        this.setDefaultCloseOperation(3);
        final JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));
        this.imagePicker = new ImagePicker(this);
        this.colorMixer = new ColorMixer();
        this.scaleSelector = new ScaleSelector();
        this.actionsController = new ActionsController(this);
        this.logField = new LogField();
        contentPane.add(this.imagePicker, "North");
        final JPanel panel1 = new JPanel();
        contentPane.add(panel1, "Center");
        panel1.setLayout(new GridLayout(0, 1, 0, 0));
        final JPanel panel2 = new JPanel();
        panel1.add(panel2, "Center");
        panel2.setLayout(new GridLayout(0, 1, 0, 0));
        final JPanel panel3 = new JPanel();
        panel2.add(panel3, "Center");
        panel3.setLayout(new GridLayout(0, 1, 0, 0));
        panel3.add(this.colorMixer);
        panel3.add(this.scaleSelector);
        panel2.add(this.actionsController);
        panel1.add(this.logField);
        this.workingImage = null;
        this.imageMask = null;
        this.imageTitle = null;
        this.pack();
    }
    
    @Override
    public void setVisible(final boolean b) {
        super.setVisible(b);
        this.log("Application started.");
    }
    
    public void changeHue() {
        final int outWidth = this.scaleSelector.width();
        final int outHeight = this.scaleSelector.height();
        final RGBWeights rgbWeights = this.colorMixer.getRGBWeights();
        final BufferedImage img = new ImageProcessor(this, this.duplicateImage(), rgbWeights, outWidth, outHeight).changeHue();
        this.present(img, "Change hue");
    }
    
    public void greyscale() {
        final BufferedImage img = new ImageProcessor(this, this.duplicateImage(), this.colorMixer.getRGBWeights()).greyscale();
        this.present(img, "Grey scale");
    }
    
    public void resize() {
        final int outWidth = this.scaleSelector.width();
        final int outHeight = this.scaleSelector.height();
        final ScaleSelector.ResizingOperation op = this.scaleSelector.resizingOperation();
        final RGBWeights rgbWeights = this.colorMixer.getRGBWeights();
        BufferedImage img = null;
        switch ($SWITCH_TABLE$edu$cg$menu$components$ScaleSelector$ResizingOperation()[op.ordinal()]) {
            case 1: {
                img = new ImageProcessor(this, this.duplicateImage(), rgbWeights, outWidth, outHeight).nearestNeighbor();
                break;
            }
            default: {
                final SeamsCarver sc = new SeamsCarver(this, this.duplicateImage(), outWidth, rgbWeights, this.duplicateMask());
                img = sc.resize();
                final boolean[][] new_mask = sc.getMaskAfterSeamCarving();
                img = new SeamsCarver(this, rotateClockwise(img), outHeight, rgbWeights, rotateMaskClockwise(new_mask)).resize();
                img = rotateCounterclockwise(img);
                break;
            }
        }
        this.present(img, "Resize: " + op.title + " [" + outWidth + "][" + outHeight + "]");
    }
    
    public void showSeamsVertical() {
        final int outWidth = this.scaleSelector.width();
        final RGBWeights rgbWeights = this.colorMixer.getRGBWeights();
        final BufferedImage vertical = new SeamsCarver(this, this.duplicateImage(), outWidth, rgbWeights, this.duplicateMask()).showSeams(Color.RED.getRGB());
        this.present(vertical, "Show seams vertical");
    }
    
    public void showSeamsHorizontal() {
        final int outHeight = this.scaleSelector.height();
        final RGBWeights rgbWeights = this.colorMixer.getRGBWeights();
        BufferedImage horizontal = new SeamsCarver(this, rotateClockwise(this.workingImage), outHeight, rgbWeights, rotateMaskClockwise(this.imageMask)).showSeams(Color.BLACK.getRGB());
        horizontal = rotateCounterclockwise(horizontal);
        this.present(horizontal, "Show seams horizontal");
    }
    
    private void present(final BufferedImage img, final String title) {
        if (img == null) {
            throw new NullPointerException("Can not present a null image.");
        }
        new ImageWindow(img, String.valueOf(this.imageTitle) + "; " + title, this).setVisible(true);
    }
    
    private static BufferedImage rotateClockwise(final BufferedImage img) {
        final int imgWidth = img.getWidth();
        final int imgHeight = img.getHeight();
        final BufferedImage ans = new BufferedImage(imgHeight, imgWidth, img.getType());
        for (int y = 0; y < imgWidth; ++y) {
            for (int x = 0; x < imgHeight; ++x) {
                final int imgX = y;
                final int imgY = imgHeight - 1 - x;
                ans.setRGB(x, y, img.getRGB(imgX, imgY));
            }
        }
        return ans;
    }
    
    private static boolean[][] rotateMaskClockwise(final boolean[][] mask) {
        final int height = mask.length;
        final int width = mask[0].length;
        final boolean[][] ans = new boolean[width][height];
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                final int X = y;
                final int Y = width - 1 - x;
                ans[Y][X] = mask[y][x];
            }
        }
        return ans;
    }
    
    private static BufferedImage rotateCounterclockwise(final BufferedImage img) {
        final int imgWidth = img.getWidth();
        final int imgHeight = img.getHeight();
        final BufferedImage ans = new BufferedImage(imgHeight, imgWidth, img.getType());
        for (int y = 0; y < imgWidth; ++y) {
            for (int x = 0; x < imgHeight; ++x) {
                final int imgX = imgWidth - 1 - y;
                final int imgY = x;
                ans.setRGB(x, y, img.getRGB(imgX, imgY));
            }
        }
        return ans;
    }
    
    private static BufferedImage duplicateImage(final BufferedImage img) {
        final BufferedImage dup = new BufferedImage(img.getWidth(), img.getHeight(), img.getType());
        for (int y = 0; y < dup.getHeight(); ++y) {
            for (int x = 0; x < dup.getWidth(); ++x) {
                dup.setRGB(x, y, img.getRGB(x, y));
            }
        }
        return dup;
    }
    
    private static boolean[][] duplicateMask(final boolean[][] mask) {
        final boolean[][] cpyMask = new boolean[mask.length][];
        for (int i = 0; i < mask.length; ++i) {
            cpyMask[i] = Arrays.copyOf(mask[i], mask[i].length);
        }
        return cpyMask;
    }
    
    private BufferedImage duplicateImage() {
        return duplicateImage(this.workingImage);
    }
    
    private boolean[][] duplicateMask() {
        return duplicateMask(this.imageMask);
    }
    
    public void setWorkingImage(final BufferedImage workingImage, final String imageTitle) {
        this.imageTitle = imageTitle;
        this.workingImage = workingImage;
        this.log("Image: " + imageTitle + " has been selected as working image.");
        this.scaleSelector.setWidth(workingImage.getWidth());
        this.scaleSelector.setHeight(workingImage.getHeight());
        this.actionsController.activateButtons();
        this.imageMask = new boolean[workingImage.getHeight()][workingImage.getWidth()];
    }
    
    public void present() {
        new ImageWindow(this.workingImage, this.imageTitle, this).setVisible(true);
    }
    
    @Override
    public void log(final String s) {
        this.logField.log(s);
    }
    
    public void setImageMask(final boolean[][] srcMask) {
        this.imageMask = duplicateMask(srcMask);
    }
    
    public void maskImage() {
        new MaskPainterWindow(this.duplicateImage(), "Mask Painter", this).setVisible(true);
    }
    
    static /* synthetic */ int[] $SWITCH_TABLE$edu$cg$menu$components$ScaleSelector$ResizingOperation() {
        final int[] $switch_TABLE$edu$cg$menu$components$ScaleSelector$ResizingOperation = MenuWindow.$SWITCH_TABLE$edu$cg$menu$components$ScaleSelector$ResizingOperation;
        if ($switch_TABLE$edu$cg$menu$components$ScaleSelector$ResizingOperation != null) {
            return $switch_TABLE$edu$cg$menu$components$ScaleSelector$ResizingOperation;
        }
        final int[] array = new int[ScaleSelector.ResizingOperation.values().length];
        try {
            array[ScaleSelector.ResizingOperation.NEAREST_NEIGHBOR.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            array[ScaleSelector.ResizingOperation.SEAM_CARVING.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        return array;
    }
}
