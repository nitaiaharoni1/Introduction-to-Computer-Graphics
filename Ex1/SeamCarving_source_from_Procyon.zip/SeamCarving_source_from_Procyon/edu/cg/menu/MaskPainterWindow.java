// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg.menu;

import java.awt.Polygon;
import java.awt.event.MouseEvent;
import java.awt.image.ImageObserver;
import java.awt.Image;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.Component;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.JPanel;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;

public class MaskPainterWindow extends JFrame
{
    private MenuWindow menuWindow;
    private BufferedImage img;
    private int imgHeight;
    private int imgWidth;
    private boolean[][] imageMask;
    private int brushSize;
    private static final int SMALL_BRUSH_SIZE = 4;
    private static final int MEDIUM_BRUSH_SIZE = 8;
    private static final int LARGE_BRUSH_SIZE = 16;
    private PainterPanel maskPainter;
    
    public MaskPainterWindow(final BufferedImage img, final String title, final MenuWindow menuWindow) {
        this.brushSize = 8;
        this.maskPainter = null;
        this.img = img;
        this.imgHeight = img.getHeight();
        this.imgWidth = img.getWidth();
        this.menuWindow = menuWindow;
        this.setTitle(title);
        final JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));
        final JPanel northPanel = new JPanel();
        northPanel.setBackground(Color.white);
        final JLabel brushLabel = new JLabel("Brush Size :  ");
        northPanel.add(brushLabel);
        final JButton btnSmallBrush = new JButton("Small");
        btnSmallBrush.addActionListener(e -> this.brushSize = 4);
        northPanel.add(btnSmallBrush);
        final JButton btnMediumBrush = new JButton("Medium");
        btnMediumBrush.addActionListener(e -> this.brushSize = 8);
        northPanel.add(btnMediumBrush);
        final JButton btnLargeBrush = new JButton("Large");
        btnLargeBrush.addActionListener(e -> this.brushSize = 16);
        northPanel.add(btnLargeBrush);
        final JButton btnClear = new JButton("Clear Mask");
        btnClear.addActionListener(e -> {
            if (this.maskPainter != null) {
                this.maskPainter.clearMask();
            }
            return;
        });
        northPanel.add(btnClear);
        contentPane.add(northPanel, "North");
        contentPane.add(this.maskPainter = new PainterPanel(), "Center");
        final JButton btnSetMask = new JButton("Set Mask");
        btnSetMask.addActionListener(e -> menuWindow.setImageMask(this.imageMask));
        contentPane.add(btnSetMask, "South");
        this.pack();
        this.setResizable(false);
        this.maskPainter.clearMask();
    }
    
    @Override
    public void setVisible(final boolean b) {
        super.setVisible(b);
        if (this.menuWindow != null) {
            this.menuWindow.log("Image: " + this.getTitle() + " has been " + (b ? "presented." : "vanished."));
        }
    }
    
    private class PainterPanel extends JPanel implements MouseListener, MouseMotionListener
    {
        private int prevX;
        private int prevY;
        private boolean dragging;
        
        public PainterPanel() {
            this.setPreferredSize(new Dimension(MaskPainterWindow.this.img.getWidth(), MaskPainterWindow.this.img.getHeight()));
            this.dragging = false;
            this.addMouseListener(this);
            this.addMouseMotionListener(this);
        }
        
        @Override
        protected void paintComponent(final Graphics g) {
            super.paintComponent(g);
            g.drawImage(MaskPainterWindow.this.img, 0, 0, null);
        }
        
        private int clipHighHeight(final int x) {
            return Math.min(x, MaskPainterWindow.this.imgHeight - 1);
        }
        
        private int clipHighWidth(final int x) {
            return Math.min(x, MaskPainterWindow.this.imgWidth - 1);
        }
        
        private int clipLow(final int x) {
            return Math.max(x, 0);
        }
        
        @Override
        public void mouseDragged(final MouseEvent e) {
            final int currentX = e.getX();
            final int currentY = e.getY();
            final int a_x = this.clipHighWidth(this.prevX + MaskPainterWindow.this.brushSize);
            final int b_x = this.clipHighWidth(currentX + MaskPainterWindow.this.brushSize);
            final int c_x = this.clipLow(currentX - MaskPainterWindow.this.brushSize);
            final int d_x = this.clipLow(this.prevX - MaskPainterWindow.this.brushSize);
            final int[] pX = { a_x, b_x, c_x, d_x };
            final int a_y = this.clipHighHeight(this.prevY + MaskPainterWindow.this.brushSize);
            final int b_y = this.clipHighHeight(currentY + MaskPainterWindow.this.brushSize);
            final int c_y = this.clipLow(currentY - MaskPainterWindow.this.brushSize);
            final int d_y = this.clipLow(this.prevY - MaskPainterWindow.this.brushSize);
            final int[] pY = { a_y, b_y, c_y, d_y };
            final Polygon poly = new Polygon(pX, pY, 4);
            final Graphics g = this.getGraphics();
            g.setColor(new Color(255, 0, 0, 50));
            g.fillPolygon(poly);
            for (int x = Math.min(d_x, c_x); x <= Math.max(b_x, a_x); ++x) {
                for (int y = Math.min(d_y, c_y); y <= Math.max(b_y, a_y); ++y) {
                    if (poly.contains(x, y)) {
                        MaskPainterWindow.this.imageMask[y][x] = true;
                    }
                }
            }
            this.prevX = currentX;
            this.prevY = currentY;
        }
        
        @Override
        public void mouseMoved(final MouseEvent e) {
        }
        
        @Override
        public void mouseClicked(final MouseEvent e) {
        }
        
        @Override
        public void mousePressed(final MouseEvent e) {
            if (this.dragging) {
                return;
            }
            this.dragging = true;
            this.prevX = e.getX();
            this.prevY = e.getY();
        }
        
        @Override
        public void mouseReleased(final MouseEvent e) {
            this.dragging = false;
        }
        
        @Override
        public void mouseEntered(final MouseEvent e) {
        }
        
        @Override
        public void mouseExited(final MouseEvent e) {
        }
        
        public void clearMask() {
            MaskPainterWindow.this.imageMask = new boolean[MaskPainterWindow.this.img.getHeight()][MaskPainterWindow.this.img.getWidth()];
            final Graphics g = this.getGraphics();
            if (g != null) {
                this.paintComponent(g);
            }
        }
    }
}
