// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg.menu.components;

import java.awt.ComponentOrientation;
import java.awt.CheckboxGroup;
import java.awt.Component;
import javax.swing.JLabel;
import java.awt.LayoutManager;
import java.awt.FlowLayout;
import javax.swing.border.Border;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import java.awt.Checkbox;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;

public class ScaleSelector extends JPanel
{
    private JFormattedTextField width;
    private JFormattedTextField height;
    private Checkbox nearestNeighbor;
    
    public ScaleSelector() {
        this.setBorder(new EtchedBorder(1, null, null));
        this.setLayout(new FlowLayout(1, 5, 5));
        this.width = this.addAndGetTextField("   Width:", 640);
        this.height = this.addAndGetTextField("   Height:", 480);
        final JLabel someSpaces = new JLabel("  ");
        this.add(someSpaces);
        final CheckboxGroup group = new CheckboxGroup();
        this.nearestNeighbor = new Checkbox("Nearest neighbor  ", group, true);
        final Checkbox seamCarving = new Checkbox("Seam carving", group, false);
        this.add(this.nearestNeighbor);
        this.add(seamCarving);
    }
    
    private JFormattedTextField addAndGetTextField(final String label, final int value) {
        final JLabel jLabel = new JLabel(label);
        this.add(jLabel);
        final JFormattedTextField tf = new JFormattedTextField((Object)value);
        tf.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        tf.setColumns(5);
        this.add(tf);
        return tf;
    }
    
    public int width() {
        final int ans = (int)this.width.getValue();
        if (ans <= 0) {
            throw new IllegalArgumentException("Width argument must be positive");
        }
        return ans;
    }
    
    public int height() {
        final int ans = (int)this.height.getValue();
        if (ans <= 0) {
            throw new IllegalArgumentException("Height argument must be positive");
        }
        return ans;
    }
    
    public ResizingOperation resizingOperation() {
        if (this.nearestNeighbor.getState()) {
            return ResizingOperation.NEAREST_NEIGHBOR;
        }
        return ResizingOperation.SEAM_CARVING;
    }
    
    public void setWidth(final int width) {
        this.width.setValue(width);
    }
    
    public void setHeight(final int height) {
        this.height.setValue(height);
    }
    
    public enum ResizingOperation
    {
        NEAREST_NEIGHBOR("NEAREST_NEIGHBOR", 0, "nearest neighbor"), 
        SEAM_CARVING("SEAM_CARVING", 1, "seam carving");
        
        public final String title;
        
        private ResizingOperation(final String s, final int n, final String title) {
            this.title = title;
        }
    }
}
