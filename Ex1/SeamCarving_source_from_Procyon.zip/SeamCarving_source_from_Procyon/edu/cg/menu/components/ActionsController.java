// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg.menu.components;

import java.awt.event.ActionEvent;
import java.util.Iterator;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.GridLayout;
import javax.swing.border.Border;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import java.util.ArrayList;
import edu.cg.menu.MenuWindow;
import java.awt.Component;
import edu.cg.Logger;
import javax.swing.JButton;
import java.util.List;
import javax.swing.JPanel;

public class ActionsController extends JPanel
{
    private List<JButton> buttons;
    private Logger logger;
    private Component mainComponent;
    
    public ActionsController(final MenuWindow menuWindow) {
        this.buttons = new ArrayList<JButton>();
        this.logger = menuWindow;
        this.mainComponent = menuWindow;
        this.setBorder(new EtchedBorder(1, null, null));
        this.setLayout(new GridLayout(0, 1, 0, 0));
        final JPanel panel1 = new JPanel();
        panel1.setBorder(new EtchedBorder(1, null, null));
        panel1.setLayout(new FlowLayout(1, 5, 5));
        this.add(panel1);
        panel1.add(this.addAndGetButton("Change hue - example", menuWindow::changeHue));
        panel1.add(this.addAndGetButton("Greyscale", menuWindow::greyscale));
        panel1.add(this.addAndGetButton("Mask Image", menuWindow::maskImage));
        panel1.add(this.addAndGetButton("Resize", menuWindow::resize));
        final JPanel panel2 = new JPanel();
        panel2.setBorder(new EtchedBorder(1, null, null));
        panel2.setLayout(new FlowLayout(1, 5, 5));
        this.add(panel2);
        panel2.add(this.addAndGetButton("Show seams - vertical", menuWindow::showSeamsVertical));
        panel2.add(this.addAndGetButton("Show seams - horizontal", menuWindow::showSeamsHorizontal));
    }
    
    private JButton addAndGetButton(final String btnName, final Runnable action) {
        final JButton btn = new JButton(btnName);
        String msg;
        btn.addActionListener(e -> {
            try {
                action.run();
            }
            catch (Exception ex) {
                msg = "Error in " + btnName + "!" + System.lineSeparator() + ex.getMessage();
                this.logger.log(msg);
                JOptionPane.showMessageDialog(this.mainComponent, msg, "Error", 0);
            }
            return;
        });
        btn.setEnabled(false);
        this.buttons.add(btn);
        return btn;
    }
    
    public void activateButtons() {
        for (final JButton btn : this.buttons) {
            btn.setEnabled(true);
        }
    }
}
