// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg.menu.components;

import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import javax.swing.JOptionPane;
import javax.imageio.ImageIO;
import java.io.File;
import javax.swing.text.JTextComponent;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import java.awt.Component;
import javax.swing.JTextField;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.BoxLayout;
import javax.swing.border.Border;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import edu.cg.menu.MenuWindow;
import javax.swing.JPanel;

public class ImagePicker extends JPanel
{
    private MenuWindow menuWindow;
    
    public ImagePicker(final MenuWindow menuWindow) {
        this.menuWindow = menuWindow;
        this.setBorder(new EtchedBorder(1, null, null));
        this.setLayout(new BoxLayout(this, 0));
        final JTextField txtFilename = new JTextField();
        txtFilename.addActionListener(e -> this.open(txtFilename.getText()));
        this.add(txtFilename);
        txtFilename.setColumns(40);
        final JButton btnBrowse = new JButton("Browse...");
        final JFileChooser fileChooser;
        final int ret;
        final String filename;
        final JTextComponent textComponent;
        btnBrowse.addActionListener(e -> {
            fileChooser = new JFileChooser();
            ret = fileChooser.showOpenDialog(menuWindow);
            if (ret == 0) {
                filename = fileChooser.getSelectedFile().getPath();
                textComponent.setText(filename);
                this.open(filename);
            }
            return;
        });
        this.add(btnBrowse);
        final JButton btnReload = new JButton("Reset to original");
        btnReload.addActionListener(e -> this.open(txtFilename.getText()));
        this.add(btnReload);
    }
    
    private void open(final String filename) {
        try {
            final File imgFile = new File(filename);
            final BufferedImage img = ImageIO.read(imgFile);
            if (img == null) {
                throw new NullPointerException();
            }
            this.menuWindow.setWorkingImage(img, imgFile.getName());
            this.menuWindow.present();
        }
        catch (Exception e) {
            final String msg = "Can't open file!";
            this.menuWindow.log(msg);
            JOptionPane.showMessageDialog(this.menuWindow, msg, "Error", 0);
        }
    }
}
