// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg.menu.components;

import edu.cg.RGBWeights;
import java.awt.ComponentOrientation;
import java.awt.Component;
import javax.swing.JLabel;
import java.awt.LayoutManager;
import java.awt.FlowLayout;
import javax.swing.border.Border;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;

public class ColorMixer extends JPanel
{
    private JFormattedTextField red;
    private JFormattedTextField green;
    private JFormattedTextField blue;
    
    public ColorMixer() {
        this.setBorder(new EtchedBorder(1, null, null));
        this.setLayout(new FlowLayout(1, 5, 5));
        final JLabel weightsLabel = new JLabel("RGB weights     ");
        this.add(weightsLabel);
        this.red = this.addAndGetTextField("      Red:");
        this.green = this.addAndGetTextField("   Green:");
        this.blue = this.addAndGetTextField("   Blue:");
    }
    
    private JFormattedTextField addAndGetTextField(final String label) {
        final JLabel jLabel = new JLabel(label);
        this.add(jLabel);
        final JFormattedTextField tf = new JFormattedTextField((Object)1);
        tf.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        tf.setColumns(5);
        this.add(tf);
        return tf;
    }
    
    public RGBWeights getRGBWeights() {
        if (!this.checkColorsValues()) {
            throw new IllegalArgumentException("The RGB weights values must be Integers between 0 and 100," + System.lineSeparator() + "and their amount must be positive.");
        }
        final int red = (int)this.red.getValue();
        final int green = (int)this.green.getValue();
        final int blue = (int)this.blue.getValue();
        return new RGBWeights(red, green, blue);
    }
    
    private boolean checkColorsValues() {
        try {
            final int red = (int)this.red.getValue();
            final int green = (int)this.green.getValue();
            final int blue = (int)this.blue.getValue();
            return red >= 0 & red <= 100 & green >= 0 & green <= 100 & blue >= 0 & blue <= 100 & red + green + blue > 0;
        }
        catch (Exception e) {
            return false;
        }
    }
}
