// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg;

import java.util.Arrays;
import java.awt.Color;
import java.awt.image.BufferedImage;

public class SeamsCarver extends ImageProcessor
{
    private int numOfSeams;
    private ResizeOperation resizeOp;
    private boolean[][] imageMask;
    private int[][] greyScaleImage;
    private long[][] m;
    private int[][] minPaths;
    private int[][] xIndices;
    private boolean[][] shiftedMask;
    private int[][] seams;
    private int k;
    private boolean[][] maskAfterSeamCarving;
    
    public SeamsCarver(final Logger logger, final BufferedImage workingImage, final int outWidth, final RGBWeights rgbWeights, final boolean[][] imageMask) {
        super(s -> logger.log("Seam carving: " + s), workingImage, rgbWeights, outWidth, workingImage.getHeight());
        this.numOfSeams = Math.abs(outWidth - this.inWidth);
        this.imageMask = imageMask;
        if (this.inWidth < 2 | this.inHeight < 2) {
            throw new RuntimeException("Can not apply seam carving: workingImage is too small");
        }
        if (this.numOfSeams > this.inWidth / 2) {
            throw new RuntimeException("Can not apply seam carving: too many seams...");
        }
        if (outWidth > this.inWidth) {
            this.resizeOp = this::increaseImageWidth;
        }
        else if (outWidth < this.inWidth) {
            this.resizeOp = this::reduceImageWidth;
        }
        else {
            this.resizeOp = this::duplicateWorkingImage;
        }
        this.maskAfterSeamCarving = null;
        this.logger.log("begins preliminary calculations.");
        if (this.numOfSeams > 0) {
            this.logger.log("initializes some additional fields.");
            this.k = 0;
            this.m = new long[this.inHeight][this.inWidth];
            this.minPaths = new int[this.inHeight][this.inWidth];
            this.seams = new int[this.numOfSeams][this.inHeight];
            this.initGreyScaleImage();
            this.initXIndices();
            this.shiftedMask = this.duplicateWorkingMask();
            this.findSeams();
        }
        this.logger.log("preliminary calculations were ended.");
    }
    
    private boolean[][] duplicateWorkingMask() {
        final boolean[][] res = new boolean[this.inHeight][this.inWidth];
        this.forEach((y, x) -> res[y][x] = this.imageMask[y][x]);
        return res;
    }
    
    private void findSeams() {
        this.logger.log("finds the " + this.numOfSeams + " minimal seams.");
        do {
            this.calculateCostsMatrix();
            this.logger.log("finds seam no: " + (this.k + 1) + ".");
            this.removeSeam();
        } while (++this.k < this.numOfSeams);
    }
    
    private void calculateCostsMatrix() {
        this.logger.log("calculates the costs matrix \"m\".");
        this.pushForEachParameters();
        this.setForEachWidth(this.inWidth - this.k);
        final MinCost minCost;
        this.forEach((y, x) -> {
            minCost = this.getMinCost(y, x);
            this.minPaths[y][x] = minCost.minX;
            this.m[y][x] = this.energyAt(y, x) + minCost.min;
            return;
        });
        this.popForEachParameters();
    }
    
    private MinCost getMinCost(final int y, final int x) {
        long min = 0L;
        int minX = x;
        if (y > 0) {
            final long mv = this.m[y - 1][x];
            long cr;
            long cl;
            long cv;
            if (x > 0 & x + 1 < this.inWidth - this.k) {
                cv = (cl = (cr = Math.abs(this.greyScaleImage[y][x - 1] - this.greyScaleImage[y][x + 1])));
            }
            else {
                cv = (cl = (cr = 255L));
            }
            long ml;
            if (x > 0) {
                cl += Math.abs(this.greyScaleImage[y - 1][x] - this.greyScaleImage[y][x - 1]);
                ml = this.m[y - 1][x - 1];
            }
            else {
                cl = 0L;
                ml = 2147483647L;
            }
            long mr;
            if (x + 1 < this.inWidth - this.k) {
                cr += Math.abs(this.greyScaleImage[y - 1][x] - this.greyScaleImage[y][x + 1]);
                mr = this.m[y - 1][x + 1];
            }
            else {
                cr = 0L;
                mr = 2147483647L;
            }
            final long sumL = ml + cl;
            final long sumV = mv + cv;
            final long sumR = mr + cr;
            min = Math.min(Math.min(sumL, sumV), sumR);
            if (min == sumR & x + 1 < this.inWidth - this.k) {
                minX = x + 1;
            }
            else if (min == sumL & x > 0) {
                minX = x - 1;
            }
        }
        return new MinCost(min, minX);
    }
    
    private void removeSeam() {
        this.logger.log("looking for the \"x\" index of the bottom row that holds the minimal cost.");
        int minX = 0;
        for (int x = 0; x < this.inWidth - this.k; ++x) {
            if (this.m[this.inHeight - 1][x] < this.m[this.inHeight - 1][minX]) {
                minX = x;
            }
        }
        this.logger.log("minX = " + minX + ".");
        this.logger.log("constructs the path of the minimal seam.");
        this.logger.log("stores the path.");
        for (int y = this.inHeight - 1; y > -1; --y) {
            this.seams[this.k][y] = this.xIndices[y][minX];
            final int greyColor = this.greyScaleImage[y][minX];
            if (minX > 0) {
                this.greyScaleImage[y][minX - 1] = (this.greyScaleImage[y][minX - 1] + greyColor) / 2;
            }
            if (minX + 1 < this.inWidth - this.k) {
                this.greyScaleImage[y][minX + 1] = (this.greyScaleImage[y][minX + 1] + greyColor) / 2;
            }
            this.shiftLeft(y, minX);
            minX = this.minPaths[y][minX];
        }
        this.logger.log("removes the seam.");
    }
    
    private void shiftLeft(final int y, final int seamX) {
        for (int x = seamX + 1; x < this.inWidth - this.k; ++x) {
            this.xIndices[y][x - 1] = this.xIndices[y][x];
            this.greyScaleImage[y][x - 1] = this.greyScaleImage[y][x];
            this.shiftedMask[y][x - 1] = this.shiftedMask[y][x];
        }
    }
    
    private long energyAt(final int y, final int x) {
        final int nextX = (x + 1 < this.inWidth - this.k) ? (x + 1) : (x - 1);
        final int nextY = (y + 1 < this.inHeight) ? (y + 1) : (y - 1);
        final long forbidden = this.shiftedMask[y][x] ? 2147483647L : 0L;
        return Math.abs(this.greyScaleImage[y][nextX] - this.greyScaleImage[y][x]) + Math.abs(this.greyScaleImage[nextY][x] - this.greyScaleImage[y][x]) + forbidden;
    }
    
    private void initXIndices() {
        this.logger.log("creates a 2D matrix of original \"x\" indices.");
        this.xIndices = new int[this.inHeight][this.inWidth];
        this.forEach((y, x) -> this.xIndices[y][x] = x);
    }
    
    private void initGreyScaleImage() {
        final BufferedImage grey = this.greyscale();
        this.greyScaleImage = new int[this.inHeight][this.inWidth];
        this.forEach((y, x) -> this.greyScaleImage[y][x] = new Color(grey.getRGB(x, y)).getRed());
    }
    
    public BufferedImage resize() {
        return this.resizeOp.resize();
    }
    
    public BufferedImage showSeams(final int seamColorRGB) {
        final BufferedImage ans = this.duplicateWorkingImage();
        if (this.numOfSeams > 0) {
            int[][] seams;
            for (int length = (seams = this.seams).length, i = 0; i < length; ++i) {
                final int[] seam = seams[i];
                final Object o;
                final int x;
                final BufferedImage bufferedImage;
                this.forEachHeight(y -> {
                    x = o[y];
                    bufferedImage.setRGB(x, y, seamColorRGB);
                    return;
                });
            }
        }
        return ans;
    }
    
    private BufferedImage reduceImageWidth() {
        this.logger.log("reduces image width by " + this.numOfSeams + " pixels.");
        final int[][] image = this.duplicateWorkingImageAs2DArray();
        int[][] seams;
        for (int length = (seams = this.seams).length, i = 0; i < length; ++i) {
            final int[] seam = seams[i];
            final Object o;
            final int x2;
            final Object o2;
            final int rgbMid;
            final int rgbLeft;
            final int rgbMix;
            final int rgbRight;
            final int rgbMix2;
            this.forEachHeight(y -> {
                x2 = o[y];
                rgbMid = o2[y][x2];
                if (x2 > 0) {
                    rgbLeft = o2[y][x2 - 1];
                    rgbMix = mixRGB(rgbMid, rgbLeft);
                    o2[y][x2 - 1] = rgbMix;
                }
                if (x2 + 1 < this.inWidth) {
                    rgbRight = o2[y][x2 + 1];
                    rgbMix2 = mixRGB(rgbMid, rgbRight);
                    o2[y][x2 + 1] = rgbMix2;
                }
                return;
            });
        }
        final BufferedImage ans = this.newEmptyOutputSizedImage();
        this.pushForEachParameters();
        this.setForEachWidth(this.outWidth);
        final int originalX;
        final Object o3;
        final int rgb;
        final Color c;
        final BufferedImage bufferedImage;
        this.forEach((y, x) -> {
            originalX = this.xIndices[y][x];
            rgb = o3[y][originalX];
            c = new Color(getRed(rgb), getGreen(rgb), getBlue(rgb));
            bufferedImage.setRGB(x, y, c.getRGB());
            return;
        });
        this.popForEachParameters();
        this.setMaskAfterWidthReduce();
        return ans;
    }
    
    private int[][] duplicateWorkingImageAs2DArray() {
        final int[][] image = new int[this.inHeight][this.inWidth];
        final Color c;
        final int r;
        final int g;
        final int b;
        final Object o;
        this.forEach((y, x) -> {
            c = new Color(this.workingImage.getRGB(x, y));
            r = c.getRed();
            g = c.getGreen();
            b = c.getBlue();
            o[y][x] = getRGB(r, g, b);
            return;
        });
        return image;
    }
    
    private static int getRGB(final int r, final int g, final int b) {
        return r << 16 | g << 8 | b;
    }
    
    private static int mixRGB(final int rgb1, final int rgb2) {
        final int r = (getRed(rgb1) + getRed(rgb2)) / 2;
        final int g = (getGreen(rgb1) + getGreen(rgb2)) / 2;
        final int b = (getBlue(rgb1) + getBlue(rgb2)) / 2;
        return getRGB(r, g, b);
    }
    
    private static int getRed(final int rgb) {
        return rgb >> 16;
    }
    
    private static int getGreen(final int rgb) {
        return rgb >> 8 & 0xFF;
    }
    
    private static int getBlue(final int rgb) {
        return rgb & 0xFF;
    }
    
    private BufferedImage increaseImageWidth() {
        this.logger.log("increases image width by + " + this.numOfSeams + " pixels.");
        this.maskAfterSeamCarving = new boolean[this.inHeight][this.outWidth];
        final int[][] image = this.duplicateWorkingImageAs2DArray();
        final int[][] rotatedSeams = this.rotateSeams();
        final Object o;
        this.forEachHeight(y -> o[y] = this.merge(o[y], rotatedSeams[y], (int)y));
        final BufferedImage ans = this.newEmptyOutputSizedImage();
        this.pushForEachParameters();
        this.setForEachWidth(this.outWidth);
        final Object o2;
        final int rgb;
        final Color c;
        final BufferedImage bufferedImage;
        this.forEach((y, x) -> {
            rgb = o2[y][x];
            c = new Color(getRed(rgb), getGreen(rgb), getBlue(rgb));
            bufferedImage.setRGB(x, y, c.getRGB());
            return;
        });
        this.popForEachParameters();
        return ans;
    }
    
    private int[] merge(final int[] imageLine, final int[] seamsLine, final int y) {
        int[] line;
        int x1;
        int i2;
        int j;
        int x2;
        for (line = new int[this.outWidth], x1 = 0, i2 = 0, j = 0; x1 < imageLine.length & i2 < seamsLine.length; line[j++] = ((x1 <= x2) ? imageLine[x1++] : this.seamsRGB(imageLine, y, seamsLine, i2++))) {
            x2 = seamsLine[i2];
            this.maskAfterSeamCarving[y][j] = ((x1 <= x2) ? this.imageMask[y][x1] : (this.imageMask[y][x2] || (x2 + 1 < this.inWidth && this.imageMask[y][x2 + 1])));
        }
        while (i2 < seamsLine.length) {
            x2 = seamsLine[i2];
            this.maskAfterSeamCarving[y][j] = (this.imageMask[y][x2] || (x2 + 1 < this.inWidth && this.imageMask[y][x2 + 1]));
            line[j++] = this.seamsRGB(imageLine, y, seamsLine, i2++);
        }
        while (x1 < imageLine.length) {
            this.maskAfterSeamCarving[y][j] = this.imageMask[y][x1];
            line[j++] = imageLine[x1++];
        }
        return line;
    }
    
    private int seamsRGB(final int[] imageLine, final int y, final int[] seamsLine, final int i) {
        final int x = seamsLine[i];
        int rgb = imageLine[x];
        if (x + 1 < this.inWidth) {
            final Color c = new Color(this.workingImage.getRGB(x + 1, y));
            final int r = c.getRed();
            final int g = c.getGreen();
            final int b = c.getBlue();
            final int rgb2 = getRGB(r, g, b);
            rgb = mixRGB(rgb, rgb2);
        }
        return rgb;
    }
    
    private int[][] rotateSeams() {
        final int[][] rotatedSeams = new int[this.inHeight][this.numOfSeams];
        this.pushForEachParameters();
        this.setForEachWidth(this.numOfSeams);
        this.forEach((y, i) -> rotatedSeams[y][i] = this.seams[i][y]);
        this.popForEachParameters();
        int[][] array;
        for (int length = (array = rotatedSeams).length, j = 0; j < length; ++j) {
            final int[] arr = array[j];
            Arrays.sort(arr);
        }
        return rotatedSeams;
    }
    
    private void setMaskAfterWidthReduce() {
        this.maskAfterSeamCarving = new boolean[this.inHeight][this.outWidth];
        this.pushForEachParameters();
        this.setForEachWidth(this.outWidth);
        this.forEach((y, x) -> this.maskAfterSeamCarving[y][x] = this.shiftedMask[y][x]);
        this.popForEachParameters();
    }
    
    public boolean[][] getMaskAfterSeamCarving() {
        return (this.maskAfterSeamCarving != null) ? this.maskAfterSeamCarving : this.duplicateWorkingMask();
    }
    
    private static class MinCost
    {
        final long min;
        final int minX;
        
        MinCost(final long min, final int minX) {
            this.min = min;
            this.minX = minX;
        }
    }
    
    @FunctionalInterface
    interface ResizeOperation
    {
        BufferedImage resize();
    }
}
