// 
// Decompiled by Procyon v0.5.30
// 

package edu.cg;

import java.util.function.Consumer;
import java.util.function.BiConsumer;
import java.util.ArrayDeque;
import java.util.Deque;

public abstract class FunctioalForEachLoops
{
    private int width;
    private int height;
    private Deque<Params> stack;
    
    public FunctioalForEachLoops() {
        final boolean b = false;
        this.height = (b ? 1 : 0);
        this.width = (b ? 1 : 0);
        this.stack = new ArrayDeque<Params>();
    }
    
    public final void setForEachParameters(final int width, final int height) {
        this.setForEachWidth(width);
        this.setForEachHeight(height);
    }
    
    public final void setForEachWidth(final int width) {
        this.width = width;
    }
    
    public final void setForEachHeight(final int height) {
        this.height = height;
    }
    
    public final int getForEachWidth() {
        return this.width;
    }
    
    public final int getForEachHeight() {
        return this.height;
    }
    
    public final void pushForEachParameters() {
        this.stack.push(new Params());
    }
    
    public final void popForEachParameters() {
        this.stack.pop().restoreParams();
    }
    
    public final void forEach(final BiConsumer<Integer, Integer> action) {
        this.forEachHeight(y -> this.forEachWidth(x -> action.accept(y, x)));
    }
    
    public final void forEachWidth(final Consumer<Integer> action) {
        for (int x = 0; x < this.width; ++x) {
            action.accept(x);
        }
    }
    
    public final void forEachHeight(final Consumer<Integer> action) {
        for (int y = 0; y < this.height; ++y) {
            action.accept(y);
        }
    }
    
    private class Params
    {
        public final int width;
        public final int height;
        
        public Params() {
            this.width = FunctioalForEachLoops.this.getForEachWidth();
            this.height = FunctioalForEachLoops.this.getForEachHeight();
        }
        
        public void restoreParams() {
            FunctioalForEachLoops.this.setForEachWidth(this.width);
            FunctioalForEachLoops.this.setForEachHeight(this.height);
        }
    }
}
